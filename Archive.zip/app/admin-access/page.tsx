"use client";

import AdminAccessGate from "@/components/admin/AdminAccessGate";

export default function AdminLoginPage() {
  return <AdminAccessGate />;
}
